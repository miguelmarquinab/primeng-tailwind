import { Component, computed, EventEmitter, inject, Input, OnInit, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/dynamicdialog';
import { Button } from 'primeng/button';
import { ToggleSwitch } from 'primeng/toggleswitch';

import { BreakpointService } from '@shared/services/breakpoint/breakpoint.service';
import { Router } from '@angular/router';
import { NgClass } from '@angular/common';

type PaymentMethod = 'niubiz' | 'pagoefectivo';

export interface PaymentMethodError {
    reason: string;
    message: string;
}

export interface PaymentMethodModalData {
    selectedPaymentMethod?: PaymentMethod;
    paymentAmount?: string;
    error?: PaymentMethodError | null;
}

@Component({
    selector: 'app-payment-method-shipment-record-pin-modal',
    imports: [Button, ToggleSwitch, FormsModule, NgClass],
    templateUrl: './payment-method-modal.component.html',
    styleUrl: './payment-method-modal.component.scss',
    standalone: true
})
export class PaymentMethodModalComponent implements OnInit {
    private readonly dynamicDialogRef = inject(DynamicDialogRef);
    private readonly dynamicDialogConfig = inject(DynamicDialogConfig);
    private readonly breakpointService = inject(BreakpointService);
    private readonly router = inject(Router);

    @Input() selectedPaymentMethod: PaymentMethod = 'niubiz';
    @Input() paymentAmount = 'S/78.33';
    @Input() error: PaymentMethodError | null = null;

    // ✅ nuevo: modo embebido
    @Input() embedded = false;

    // ✅ nuevo: evento para wizard
    @Output() paymentConfirmed = new EventEmitter<{ paymentMethod: PaymentMethod; termsAccepted: boolean }>();

    // ✅ nuevo: evento para “ir a finish” desde wizard
    @Output() goToFinishRequested = new EventEmitter<void>();

    termsAccepted = false;
    isMobile = computed(() => this.breakpointService.isMobile());

    ngOnInit(): void {
        const data = this.dynamicDialogConfig.data as PaymentMethodModalData | undefined;
        if (data) {
            if (data.selectedPaymentMethod) {
                this.selectedPaymentMethod = data.selectedPaymentMethod;
            }
            if (data.paymentAmount) {
                this.paymentAmount = data.paymentAmount;
            }
            if (data.error !== undefined) {
                this.error = data.error;
            }
        }
    }

    selectPaymentMethod(method: PaymentMethod): void {
        this.selectedPaymentMethod = method;
    }

    onPay(): void {
        if (this.termsAccepted && !this.error) {
            this.dynamicDialogRef.close({
                paymentMethod: this.selectedPaymentMethod,
                termsAccepted: this.termsAccepted
            });
        }
    }

    onRetry(): void {
        this.error = null;
    }

    close(): void {
        this.dynamicDialogRef.close();
    }

    goToFinish() {
        this.dynamicDialogRef.close();
        this.router.navigate(['/shipment-record/finish']);
    }
}
