import { Component, EventEmitter, inject, Input, OnInit, Output } from '@angular/core';
import { InputOtp } from 'primeng/inputotp';
import { Button } from 'primeng/button';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { DynamicDialogRef } from 'primeng/dynamicdialog';

@Component({
    selector: 'app-markup-shipment-record-pin-modal',
    imports: [InputOtp, Button, ReactiveFormsModule],
    templateUrl: './pin-modal.component.html',
    styleUrl: './pin-modal.component.scss',
    providers: [],
    standalone: true
})
export class PinModal implements OnInit {
    form!: FormGroup;
    formBuilder = inject(FormBuilder);
    private readonly dynamicDialogRef = inject(DynamicDialogRef);

    // ✅ nuevo: si el componente está dentro del wizard
    @Input() embedded = false;

    // ✅ nuevo: el wizard escucha este evento
    @Output() pinSubmitted = new EventEmitter<string>();

    ngOnInit(): void {
        this.initPinForm();
    }

    initPinForm() {
        this.form = this.formBuilder.group({
            pin: ['', [Validators.required]]
        });
    }

    next() {
        if (this.form.valid) {
            const pinValue: string = String(this.form.value.pin ?? '').trim();

            // embebido: no cerramos dialog, emitimos al wizard
            if (this.embedded) {
                this.pinSubmitted.emit(pinValue);
                return;
            }

            // modal independiente (como antes)
            this.dynamicDialogRef.close(pinValue);
        }
    }
}
